<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-3 p-5">
            <img src="/images/img.jpg" width="100px" class="rounded-circle">
        </div>
        <div class="col-9 pt-5">
            <div class="d-flex justify-content-between align-items-baseline">
                <h1><?php echo e($user->username); ?></h1>   
                <a href="" style="float: right;" class="btn btn-primary">Add New Post</a>             
            </div>
                <div class="d-flex">
                <div class="pr-5"><strong>40</strong> posts</div>
                <div class="pr-5"><strong>300k</strong> followers</div>
                <div class="pr-5"><strong>40k</strong> following</div>
            </div>
            <div class="pt-4 font-weight-bold"><?php echo e($user->profiles->title); ?></div>
            <div><?php echo e($user->profiles->description); ?></div>
            <div><a href="#"><?php echo e($user->profiles->url); ?></a></div>
        </div>
    </div>

    <div class="row pt-5">
        <div class="col-4"> 
                <img src="/images/10.jpg" class="w-20">
        </div>
        <div class="col-4"> 
                <img src="/images/11.jpg" class="w-20">
        </div>
        <div class="col-4"> 
                <img src="/images/12.jpg" class="w-20">
        </div>
    </div>  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\igclone\resources\views/home.blade.php ENDPATH**/ ?>