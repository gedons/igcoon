<div>
    
    	<?php if(session()->has('message')): ?>
    		 <div class='alert alert-success'><?php echo e(session()->get('message')); ?></div>
    	
    	<?php elseif(session()->has('error')): ?>
    		<div class='alert alert-danger'>session()->get('error')</div>
    	<?php endif; ?>
     
</div><?php /**PATH C:\xampp\htdocs\laravel\igclone\resources\views/components/alert.blade.php ENDPATH**/ ?>