

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-3 p-5">
            <img src="/images/img.jpg" width="100px" class="rounded-circle">
        </div>
        <div class="col-9 pt-5">
            <div class="d-flex justify-content-between align-items-baseline">
                <h1><?php echo e($user->username); ?></h1>   
                <a href="<?php echo e(route('post.create')); ?>" style="float: right;" class="btn btn-primary">Add New Post</a>             
            </div>
                <div class="d-flex">
                <div class="pr-5"><strong><?php echo e($user->posts->count()); ?></strong> posts</div>
                <div class="pr-5"><strong>300k</strong> followers</div>
                <div class="pr-5"><strong>40k</strong> following</div>
            </div>
            <div class="pt-4 font-weight-bold"><?php echo e($user->profiles->title); ?></div>
            <div><?php echo e($user->profiles->description); ?></div>
            <div><a href="#"><?php echo e($user->profiles->url); ?></a></div>
        </div>
    </div>

    <div class="row pt-5">
        <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 pb-4"> 
                <img src="/storage/<?php echo e($post->image); ?>" class="w-100">
        </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\igclone\resources\views/profiles/index.blade.php ENDPATH**/ ?>